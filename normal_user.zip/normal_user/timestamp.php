
<?php

date_default_timezone_set('Asia/Manila');
$time = date("h:i:s");
